<?php
/**
 * Modern E-Ticaret Ana Sayfa - OpenCart Benzeri Dinamik Yapı
 */

// Check if database is installed
try {
    if (!file_exists(__DIR__ . '/includes/config.php')) {
        header('Location: /install.php');
        exit;
    }

    require_once 'includes/config.php';
    require_once 'includes/database.php';
    require_once 'includes/functions.php';
    require_once 'includes/security.php';

    // Check if tables exist
    $result = dbQueryOne("SELECT COUNT(*) as cnt FROM site_settings", []);
    if (!$result || $result['cnt'] == 0) {
        // Kurulum yapılmamış, install sayfasına yönlendir
        header('Location: /install.php');
        exit;
    }

} catch (Exception $e) {
    // Hata durumunda log kaydı
    error_log("Index.php Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());

    // Geliştirme modunda hatayı göster
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        die("Hata: " . $e->getMessage() . "<br>Dosya: " . $e->getFile() . "<br>Satır: " . $e->getLine());
    }

    // Production'da install sayfasına yönlendir
    header('Location: /install.php');
    exit;
}

$pageTitle = getSetting('site_name', 'E-Ticaret') . ' - Ana Sayfa';

// Get active slider with items
$slider = dbQueryOne("SELECT * FROM sliders WHERE status = 1 AND type = 'main' ORDER BY id ASC LIMIT 1");
$sliderItems = [];
if ($slider) {
    $now = date('Y-m-d H:i:s');
    $sliderItems = dbQuery("
        SELECT * FROM slider_items
        WHERE slider_id = ? AND status = 1
        AND (start_date IS NULL OR start_date <= ?)
        AND (end_date IS NULL OR end_date >= ?)
        ORDER BY sort_order ASC
    ", [$slider['id'], $now, $now]);
}

// Get featured products
$featuredProducts = dbQuery("
    SELECT p.*, c.name as category_name, p.main_image as image
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.status = 1 AND p.is_featured = 1
    ORDER BY p.sort_order ASC LIMIT 8
");

// Get new products
$newProducts = dbQuery("
    SELECT p.*, c.name as category_name, p.main_image as image
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.status = 1 AND p.is_new = 1
    ORDER BY p.created_at DESC LIMIT 8
");

// Get bestseller products (most ordered)
$bestsellerProducts = dbQuery("
    SELECT p.*, c.name as category_name, p.main_image as image, COALESCE(SUM(oi.quantity), 0) as sold
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN order_items oi ON p.id = oi.product_id
    WHERE p.status = 1
    GROUP BY p.id
    ORDER BY sold DESC LIMIT 8
");

// Get special offers (discounted products)
$specialProducts = dbQuery("
    SELECT p.*, c.name as category_name, p.main_image as image,
    ROUND(((p.price - p.sale_price) / p.price) * 100) as discount_percent
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.status = 1 AND p.sale_price > 0 AND p.sale_price < p.price
    ORDER BY discount_percent DESC LIMIT 8
");

// Get categories
$categories = dbQuery("
    SELECT c.*, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON c.id = p.category_id AND p.status = 1
    WHERE c.parent_id = 0 AND c.status = 1
    GROUP BY c.id
    ORDER BY c.sort_order ASC LIMIT 8
");

// Get banners
$homeBanners = dbQuery("
    SELECT bi.* FROM banner_items bi
    JOIN banners b ON bi.banner_id = b.id
    WHERE b.position = 'home_middle' AND bi.status = 1
    AND (bi.start_date IS NULL OR bi.start_date <= NOW())
    AND (bi.end_date IS NULL OR bi.end_date >= NOW())
    ORDER BY bi.sort_order ASC LIMIT 3
");

// Theme settings
$themeSettings = [];
$themeResult = dbQuery("SELECT setting_key, setting_value FROM theme_settings");
foreach ($themeResult as $row) {
    $themeSettings[$row['setting_key']] = $row['setting_value'];
}

$primaryColor = $themeSettings['primary_color'] ?? '#2563eb';
$secondaryColor = $themeSettings['secondary_color'] ?? '#7c3aed';
$accentColor = $themeSettings['accent_color'] ?? '#f59e0b';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars(getSetting('site_description', 'Profesyonel E-Ticaret Sitesi')) ?>">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" rel="stylesheet">

    <style>
        :root {
            --primary: <?= $primaryColor ?>;
            --secondary: <?= $secondaryColor ?>;
            --accent: <?= $accentColor ?>;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
        }

        /* Header */
        .top-bar {
            background: var(--primary);
            color: white;
            padding: 8px 0;
            font-size: 13px;
        }

        .main-header {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }

        .search-box {
            max-width: 500px;
        }

        .search-box input {
            border-radius: 25px 0 0 25px;
            border: 2px solid #e5e7eb;
            padding: 10px 20px;
        }

        .search-box button {
            border-radius: 0 25px 25px 0;
            background: var(--primary);
            border: 2px solid var(--primary);
            padding: 10px 20px;
        }

        .header-icons a {
            color: #4b5563;
            font-size: 1.2rem;
            margin-left: 20px;
            position: relative;
        }

        .header-icons a:hover {
            color: var(--primary);
        }

        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--accent);
            color: white;
            font-size: 10px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Slider */
        .hero-slider {
            position: relative;
            overflow: hidden;
        }

        .hero-slide {
            position: relative;
            height: 500px;
        }

        .hero-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .hero-content {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            padding: 40px;
            max-width: 600px;
        }

        .hero-content h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .hero-content p {
            font-size: 1.2rem;
            margin-bottom: 25px;
        }

        /* Section */
        .section-title {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 15px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: var(--primary);
        }

        /* Product Card */
        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s;
            height: 100%;
            border: 1px solid #e5e7eb;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        .product-image {
            position: relative;
            height: 220px;
            overflow: hidden;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }

        .product-card:hover .product-image img {
            transform: scale(1.05);
        }

        .product-badges {
            position: absolute;
            top: 10px;
            left: 10px;
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .badge-new {
            background: var(--primary);
        }

        .badge-sale {
            background: #ef4444;
        }

        .badge-featured {
            background: var(--accent);
        }

        .product-actions {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            opacity: 0;
            transform: translateX(10px);
            transition: all 0.3s;
        }

        .product-card:hover .product-actions {
            opacity: 1;
            transform: translateX(0);
        }

        .product-actions button {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: white;
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .product-actions button:hover {
            background: var(--primary);
            color: white;
        }

        .product-body {
            padding: 15px;
        }

        .product-category {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .product-title {
            font-size: 14px;
            font-weight: 600;
            margin: 8px 0;
            color: #1f2937;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .product-rating {
            color: #fbbf24;
            font-size: 12px;
            margin-bottom: 8px;
        }

        .product-price {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .current-price {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary);
        }

        .old-price {
            font-size: 0.9rem;
            color: #9ca3af;
            text-decoration: line-through;
        }

        .btn-add-cart {
            width: 100%;
            margin-top: 10px;
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 10px;
            font-weight: 600;
            transition: all 0.2s;
        }

        .btn-add-cart:hover {
            background: var(--secondary);
            transform: scale(1.02);
        }

        /* Category Card */
        .category-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s;
            border: 1px solid #e5e7eb;
            height: 100%;
        }

        .category-card:hover {
            border-color: var(--primary);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
        }

        .category-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 1.5rem;
        }

        /* Banner */
        .promo-banner {
            border-radius: 12px;
            overflow: hidden;
            position: relative;
        }

        .promo-banner img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        /* Features */
        .feature-box {
            background: white;
            border-radius: 12px;
            padding: 30px;
            text-align: center;
            height: 100%;
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: var(--primary);
            font-size: 1.5rem;
        }

        /* Footer */
        .footer {
            background: #1f2937;
            color: #9ca3af;
            padding: 60px 0 30px;
            margin-top: 60px;
        }

        .footer h5 {
            color: white;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .footer-links {
            list-style: none;
            padding: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #9ca3af;
            text-decoration: none;
            transition: color 0.2s;
        }

        .footer-links a:hover {
            color: white;
        }

        .social-links a {
            color: white;
            font-size: 1.5rem;
            margin-right: 15px;
        }

        .newsletter-form input {
            border-radius: 8px 0 0 8px;
        }

        .newsletter-form button {
            border-radius: 0 8px 8px 0;
        }

        @media (max-width: 768px) {
            .hero-slide {
                height: 300px;
            }
            .hero-content h1 {
                font-size: 1.8rem;
            }
            .hero-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<!-- Top Bar -->
<div class="top-bar">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <i class="fas fa-phone-alt me-2"></i> <?= htmlspecialchars(getSetting('site_phone', '0850 123 45 67')) ?>
                <span class="mx-3">|</span>
                <i class="fas fa-envelope me-2"></i> <?= htmlspecialchars(getSetting('site_email', 'info@eticaret.com')) ?>
            </div>
            <div class="col-md-6 text-end">
                <i class="fas fa-truck me-2"></i> 500 TL Üzeri Ücretsiz Kargo
            </div>
        </div>
    </div>
</div>

<!-- Main Header -->
<header class="main-header py-3">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3">
                <a href="/" class="logo">
                    <?php if (!empty($themeSettings['logo'])): ?>
                        <img src="/uploads/theme/<?= htmlspecialchars($themeSettings['logo']) ?>" alt="Logo" style="max-height: 50px;">
                    <?php else: ?>
                        <i class="fas fa-shopping-cart"></i> <?= htmlspecialchars(getSetting('site_name', 'E-Ticaret')) ?>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-md-6">
                <form action="/search.php" method="GET" class="search-box d-flex mx-auto">
                    <input type="text" name="q" class="form-control" placeholder="Ürün ara...">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="col-md-3">
                <div class="header-icons text-end">
                    <?php if (isLoggedIn()): ?>
                        <a href="/account.php" title="Hesabım"><i class="fas fa-user"></i></a>
                    <?php else: ?>
                        <a href="/login.php" title="Giriş Yap"><i class="fas fa-user"></i></a>
                    <?php endif; ?>
                    <a href="/wishlist.php" title="İstek Listesi"><i class="fas fa-heart"></i></a>
                    <a href="/cart.php" title="Sepet">
                        <i class="fas fa-shopping-cart"></i>
                        <?php $cartCount = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>
                        <?php if ($cartCount > 0): ?>
                            <span class="cart-count"><?= $cartCount ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Hero Slider -->
<?php if (!empty($sliderItems)): ?>
<section class="hero-slider">
    <div class="swiper mainSwiper">
        <div class="swiper-wrapper">
            <?php foreach ($sliderItems as $item): ?>
                <div class="swiper-slide">
                    <div class="hero-slide">
                        <img src="/uploads/sliders/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['title']) ?>">
                        <?php if ($item['title'] || $item['subtitle']): ?>
                            <div class="hero-content" style="<?= $item['text_position'] === 'right' ? 'right: 0;' : ($item['text_position'] === 'center' ? 'left: 50%; transform: translate(-50%, -50%); text-align: center;' : '') ?>; color: <?= $item['text_color'] ?>;">
                                <?php if ($item['title']): ?>
                                    <h1><?= htmlspecialchars($item['title']) ?></h1>
                                <?php endif; ?>
                                <?php if ($item['subtitle']): ?>
                                    <p><?= htmlspecialchars($item['subtitle']) ?></p>
                                <?php endif; ?>
                                <?php if ($item['button_text'] && $item['button_url']): ?>
                                    <a href="<?= htmlspecialchars($item['button_url']) ?>" class="btn btn-<?= htmlspecialchars($item['button_style']) ?> btn-lg">
                                        <?= htmlspecialchars($item['button_text']) ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($slider && !empty($slider['show_dots'])): ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if ($slider && !empty($slider['show_arrow WHERE p.status = 1
    dif;                "<br>Satır: " . $e->getLine());
    }

    // Production'da install sayfas?<?php endif; ?>
        <?php if ($sl
<!-- Herro-slidy($slide <?php if ainer my-5">
    <div cpass="r ($sl
 <lin  .featuf="https:ro-slider">
   mbss="row j  // Production'         <i class="fasd-3">
                <div class="header-icons text         ba      <div class="hero-slide">
              wia-heart"></i></a>
 500 T                </div>
           h6>           </di                          t-muted">En az 6 karakter retsiz K�rgo
 sipas="flmak                         <  </div>
        </div>
    </div>"fasd-3">
                <div class="header-icons text         ba      <div class="hero-slide">
              wia-heart"></i></a>
 sh    ?= h                </div>
           h6>Güvenli Ödeme                          t-muted">En az 6 karakter 256-bit SSL güvenlik                        <  </div>
        </div>
    </div>"fasd-3">
                <div class="header-icons text         ba      <div class="hero-slide">
              wia-heart"></i></a>
 undo                </div>
           h6>Kolay İade                          t-muted">En az 6 karakter 14 gün edin.    ak                         <  </div>
        </div>
    </div>"fasd-3">
                <div class="header-icons text         ba      <div class="hero-slide">
              wia-heart"></i></a>
 o Slseh                </div>
           h6>7/24 Declas                          t-muted">En az 6 karakter ?ph zamuntyan mutludif (z                        <  </div>
        </div>
    </div>
</header>

<ro-slidy( ($sl
 <liCEFT JOIN pf="https:sliderItems)): ?>LEFT JOIN     dif;   :ro-slider">
   mbss="row j  // rişim Engter {
       ">KEFT JOIlma <p class="lea Production'         <i class="fasdiderItems as $iLEFT JOIN p                 <div class="swiper-slide">
      6        4     lg                        <p" title="Se      t">
?slug=ars($item['button_textSe      E plugn btn-<?= htmlsnone;
         - tra          <div class="card-header">
      {
                      <form method="POSTeader">
      {
      wia-                <?php if ($item['button_textSe      E "<?= htm                        <a href="<?= htmls/sliders/<?= htmlsLEFT JOIN hars($item['image']) ?>Se      E "<?= htmlspecialchm['text_p       4          <?php else: ?>
   if ($item['button                <a href="/login.pef="<?= htmls/art"></i></a>
 f...">              <?php $cartCount ($item['button                     </div>
                        <?php endif; ?>
      h6er">
   mbs1"hars($item['subtitle'])Se      E ')) ?                               ?>
      -muted">En az 6 karakter </span>      E  FROM categor                                    </div>

           </div>
              </div>
            </div>
        </d?>
        </div>
        <?php if ($sl
<ro-slidy(  </d?>
     php if a  </d <lin  .fead y("
    Sf="https:sliderItems)): ?>= dbQuery("
        dif;   :ro-slider">
   mbss="row j  //  gap-2 d-md-fent-md-center">
     betweener">
            <d       <i class="fas rişim Engter {
           0">Öne Çıkunt      lma <p class="lea"fas " title="Se      t">
?fil <d== dbQuer<?= htmlspecialchout                 sm">Tüm   ü Gör-arrow-left"></i> Geri Dem['t    1              <a hrdiv>
    </div>
Production'         <i class="fasdiderItems as $i= dbQuery("
    S     FROM c     <div class="swiper-slide">
      6        4     lg                        <p-slide">
  r .product-a          <div class="card-header">
    {
                        <form method="POST" title=" {
    t">
?slug=ars($item['button_text {
    E plugn btn-<         <?php $cartCount ($item['b/sliders/<?= htmlsd = p.cahars($item['image']) ?> {
    E "<?= ht ?:isi.      .jpg'mlspecialchars($item['title']) ?> {
    E ')) ?                   <form method="POST                   <?php endif; header">
    {
         poa-                <?php if ($item['button_text {
    E "ER BYhtm    -count"><?= $    p        barar *<                                      <?php if ($item['button_text {
    E "ER= dbQuerhtm    -count"><?= $    p       = dbQuer<>Öne Çıkun                                      <?php if ($item['button_text {
    E ice
    ORht ice url' {
    E ice
    ORht <l' {
    E    ORhtm                        <a href="<?= htmlscount"><?= $    p       ice
">-%ars(     (((' {
    E    ORht -l' {
    E ice
    ORht0) a' {
    E    ORhtmnt_perce                 <?php endif; ?>
 ($item['button                     </div>
                        <?php endif; ?>
      eader">
    {
     ver {
 a-                <?php if ($item['bit" claonclick="addToWe="İst( ?>;
  
    E "d     )istesi"><i class="fas fne Eke
">heart"></i></a>
                     </form>
         ?php if ($item['bit" claonclick="quickView( ?>;
  
    E "d     )istesi"><H (zlı Bakfas�">heart"></i></a>
 eye               </form>
         ?php if ($it              <?php endif; ?>
               <?php endif; ?>
  eader">
    {
      ody              <form method="POSTeader">
   {
            fo"hars($item['subtitle'])  
    E main_image as?>
<!DOGenel'ce                <?php endif; ?>
      h5er">
   {
           "></form>
         ?php if ($item['b" title=" {
    t">
?slug=ars($item['button_text {
    E plugn btn-<?= htmlsnone;
         - trale="fontrk                          <?= htmlspeciars($item['title']) ?> {
    E ')) ?     </form>
         ?php if ($item['b                   <?php endif; h/h5             <form method="POSTeader">
   {
          coa-                <?php if ($item['buttontemext'star; t's<= 5; t'++m                        <a href="<?= htmls/art"></i><olor']s<= ?> {
    E     co?>
<!Drce  's: <?=tran>a>
 sta>              <?php $cartCount ($item['button   tem                    <?php if ($item['bcount"><?= $ 6 karakte    1  ( ?>;
  
    E re="wiategor    !Dr   )               <?php endif; ?>
 ($it              <?php endif; ?>
      eader">
    {
        ORa-                <?php if ($item['bcount"><?= $c          fo"hars(50%,atP  foxt {
    E ice
    ORht ice ?l' {
    E ice
    ORht :a' {
    E    ORhtmn                 <?php endif; ?>
 ($item['button_text {
    E ice
    ORht ice url' {
    E ice
    ORht <l' {
    E    ORhtm                        <a href="<?= htmlscount"><?= $       fo"hars(50%,atP  foxt {
    E    ORhtmn                 <?php endif; ?>
 ($item['button                     </div>
                        <?php endif; ?>
      it" claimary btn-lg">
                    "aonclick="addTomik ( ?>;
  
    E "d     )i         <?php $cartCount ($item['b/art"></i></a>
 cartCplusL Üzeri Üc     e Eke
            </div>
                   </form>
         ?php if           </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if ($sl
<ro-slidy(  </d?>
     php if a  </d <li("
    Sf="https:sliderItems)): ?>uery("
        dif;   :ro-slider">
   mbss="row j  //  gap-2 d-md         <i class="fasdiderItems as $iuery("
    S               <div class="swiper-slide">
         4                      <p" title=ars($item['title']) ?>      ['    ?>
<!DOC'btn-<?= htmls{
           drişe           <img src="/uploads/sliders/<?= htmlsanner_ihars($item['image']) ?>      ['"<?= htmlspecialchars($item['title']) ?>      ['                     <?php if ($it    </div>
            </div>
        </d?>
        </div>
        <?php if ($sl
<ro-slidy(  </d?>
     php if a  </d <liNew y("
    Sf="https:sliderItems)): ?>uery("
        dif;   :ro-slider">
   mbss="row j  //  gap-2 d-md-fent-md-center">
     betweener">
            <d       <i class="fas rişim Engter {
           0"> içi      lma <p class="lea"fas " title="Se      t">
?fil <d= bar?= htmlspecialchout                 sm">Tüm   ü Gör-arrow-left"></i> Geri Dem['t    1              <a hrdiv>
    </div>
Production'         <i class="fasdiderItems as $iuery("
    S     FROM c     <div class="swiper-slide">
      6        4     lg                        <p-slide">
  r .product-a          <div class="card-header">
    {
                        <form method="POST" title=" {
    t">
?slug=ars($item['button_text {
    E plugn btn-<         <?php $cartCount ($item['b/sliders/<?= htmlsd = p.cahars($item['image']) ?> {
    E "<?= ht ?:isi.      .jpg'mlspecialch              <form method="POST                   <?php endif; header">
    {
         poa-                <?php if ($item['bcount"><?= $    p        barar *<       </form>
         ?php if ($it              <?php endif; ?>
               <?php endif; ?>
  eader">
    {
      ody              <form method="POSTeader">
   {
            fo"hars($item['subtitle'])  
    E main_image as?>
<!DO'ce                <?php endif; ?>
      h5er">
   {
           ">ars($item['title']) ?> {
    E ')) ?     h/h5             <form method="POSTeader">
   {
         ORa-                <?php if ($item['bcount"><?= $c          fo"hars(50%,atP  foxt {
    E ice
    ORht ice ?l' {
    E ice
    ORht :a' {
    E    ORhtmn                 <?php endif; ?>
 ($it              <?php endif; ?>
      it" claimary btn-lg">
                    "aonclick="addTomik ( ?>;
  
    E "d     )i         <?php $cartCount ($item['b/art"></i></a>
 cartCplusL Üzeri Üc     e Eke
            </div>
                   </form>
       ; ?>
 ($it              <?php endif;       </div>
            <?php endforeach; ?>
        </div>
        <?php if ($sl
<ro-slidy(  </d?>
     php if a  </d <liSscounteO produf="https:sliderItems)): ?> dbQuery("
        dif;   :ro-slider">
   mbss="row j  //  gap-2 d-md-fent-md-center">
     betweener">
            <d       <i class="fas rişim Engter {
           0">İLocaiml�i      lma <p class="lea"fas " title="Se      t">
?fil <d=ice
"?= htmlspecialchout     dang<d     sm">Tüm   ü Gör-arrow-left"></i> Geri Dem['t    1              <a hrdiv>
    </div>
Production'         <i class="fasdiderItems as $Geray_sl foxt dbQuery("
    , 0, 4)S     FROM c     <div class="swiper-slide">
      6        4     lg                        <p-slide">
  r .product-a          <div class="card-header">
    {
                        <form method="POST" title=" {
    t">
?slug=ars($item['button_text {
    E plugn btn-<         <?php $cartCount ($item['b/sliders/<?= htmlsd = p.cahars($item['image']) ?> {
    E "<?= ht ?:isi.      .jpg'mlspecialch              <form method="POST                   <?php endif; header">
    {
         poa-                <?php if ($ndif; hcount"><?= $    p       ice
">-%ars(> {
    E DESC LIMIT 8
");            </form>
         ?php if ($it              <?php endif; ?>
               <?php endif; ?>
  eader">
    {
      ody              <form method="POSTeader">
   {
            fo"hars($item['subtitle'])  
    E main_image as?>
<!DO'ce                <?phpform method="POSTh5er">
   {
           ">ars($item['title']) ?> {
    E ')) ?     h/h5             <form method="POSTeader">
   {
         ORa-                <?php if ($item['bcount"><?= $c          fo"hars(50%,atP  foxt {
    E ice
    ORhtmn                 <?php endif; ?>
 ($item['bcount"><?= $       fo"hars(50%,atP  foxt {
    E    ORhtmn                 <?php endif; ?>
 ($it              <?php endif; ?>
      it" claimary btn-lg">
                    "aonclick="addTomik ( ?>;
  
    E "d     )i         <?php $cartCount ($item['b/art"></i></a>
 cartCplusL Üzeri Üc     e Eke
            </div>
                   </form>
       ; ?>
 ($it              <?php endif;       </div>
            <?php endforeach; ?>
        </div>
        <?php if ($sl
<ro-slidy(  </d?>
     php if a Header -->
< .footepty($       ol" placeotss="swiper mainSwiper   <div class="row align-items-cente     <i class="fasd-3">
             4                   Th5>ars($item['title']) ?name', 'E-Ticaret')) ?>
                h/h5             <formlchars($item['subtitle']description', 'Profesyonel E-Ticaret Sitesi')) ?>">

   s   i      h/                  < Production'd                                 <p" title=#">heart"></i><ba>
 facebook              <a hr           <p" title=#">heart"></i><ba>
   exigram              <a hr           <p" title=#">heart"></i><ba>
 twitt                <?php endif; ?>
  " title=#">heart"></i><ba>
 youtube              <?php endif;   </div>
        </div>
    </div>"fasd-3">
             2                   Th5>s="fas fh/h5             <formlul ol" placeotss                            <pl   php" title="Hesabım">s="fas fh/ürll          <?php $cartCopl   php" title="Hesabım?tab=px 8p   Sipas="flmaifh/ürll          <?php $cartCopl   php" titlle="İstek Li>i class="fas fh/ürll          <?php $cartCopl   php" titlSepet">
 >     ifh/ürll          <?php $ca</uliv>
        </div>
    </div>"fasd-3">
             2                   Th5>Bilgih/h5             <formlul ol" placeotss                            <pl   php" titltle>t">
?slug=hakkimizda">sakks ftludih/ürll          <?php $cartCopl   php" titlS  <dctek Li>i l  işifh/ürll          <?php $cartCopl   php" titltle>t">
?slug=sef="S.S.Sh/ürll          <?php $cartCopl   php" titltle>t">
?slug=gizlilik  Gizlilikh/ürll          <?php $ca</uliv>
        </div>
    </div>"fasd-3">
             4                   Th5>Bül <nh/h5             <formlchKam   yalt-aunthabe-aur olun!h/                  < rch.p
      utton {
        -fent-"php" methoutton {
  " class="searcPOST      <input type="text" name="q" clcaret"form-cocaret"fol" placeholder="Ürün ara...">
 E-poexi adrs fniz"cludes/sd     <input type="text"it" class="btn btn-primary"><i class="fas fa-Göndma <       </form>
            </div>
            <div class="c  <div class="c hder py-3">y 4 ['text_p(--primary);
 #374151;lass="row align-items-c 6 ka    <div class="col-mdper">
   mbs0">&copy;iars(');
   'ce  hars(getSetting('site_name', 'E-Ticaret')) ?>
                . Tümthaklt-ı saklıdır.h/           
</header>

<!-- Herceotsser -->
<Ssyoneduf="h<esyoneiders/ivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.minjss" rel="styel="styleshjs    esyone"h<esyoneiders/ivr.net/npm/bootstrap@5.3.0/dbundle.min.css" rel="styleshjs    esyone"h<esyone>s
$tI>
    ize <div c
    eid>
    =wProd<div c('.    <div c?>
 paddilo }

truprice -           padding: otsaColor ?>; WHERE         _etted?>
<!D500r   ,padding: oi"faleOnf;
  a       falsprice -}rice -effo-s:isor ?>; WHERE  nfasr' ? 'l<!DO; WHEran>'rice ->
           padding: el:is."></div>
        ',padding: clickfale

truprice -}rice -navig        padding: getLEl:is."></div . $e->getL',padding: fas?El:is."></div . $e->fas?'rice -}ri}ings
$tAdd to.catt
fun-slideaddTomik (  
    Idhero-slifetch('lSepe    
}

$,  padding: s="sea:isPOST',padding: o Slids   'C>
     Ts="':isapplic     /x-www     -urlencoded?},padding:  ody:isERE p.stat=' +   
    Id + '&sold
   =1'ice -}.sort_.then(  => rhjsonbi.sort_.then(');a =>  padding: rIte');a.successhero-slide {
   ce
k ('       s    e eke
  p!'nt-size: 1.5remloc     .re htm(     .categon    ero-slide {
   ce
k (');a.mess    || 'H);a oluştu'     .categorce -}.red prodAdd to.We="İst
fun-slideaddToWe="İst(  
    Idhero-slifetch('lle="İstek L$,  padding: s="sea:isPOST',padding: o Slids   'C>
     Ts="':isapplic     /x-www     -urlencoded?},padding:  ody:ishp" metadd&ERE p.stat=' +   
    Idice -}.sort_.then(  => rhjsonbi.sort_.then(');a =>  padding: ce
k (');a.mess        .c}.red   esyone"